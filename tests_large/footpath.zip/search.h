
#ifndef SEARCH
	#define SEARCH
	
	int approx_binary_search(void *A[], int n, void *T, double (*minus)(void *, void *));

#endif
