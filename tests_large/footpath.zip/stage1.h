
#ifndef STAGE1

	#define STAGE1
	
	void stage1(char data_file_name[], char output_file_name[]);

#endif