#ifndef DRIVER
    #define DRIVER

    #define MAX_PATH 256

    int string_ends_with(char string[], char end[]);


#endif
