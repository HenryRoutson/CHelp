
#ifndef STAGE2

	#define STAGE2

	void stage2(char data_file_name[], char output_file_name[]);
	int grade1in_cmp(const void *p1, const void *p2);
	double grade1in_minus(void *p_struct, void *p_query);

#endif
